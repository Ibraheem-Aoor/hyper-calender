<strong>Copyright &copy; 2021 <a href="https://smartrahat.com">smartrahat</a>.</strong>
All rights reserved.
<div class="float-right d-none d-sm-inline-block">
    <b>Version</b> 1.0.0
</div>
