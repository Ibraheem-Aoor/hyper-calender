<?php echo e(Form::open(['url'=>'task/store','method'=>'post'])); ?>

<div class="modal-body">
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <?php echo e(Form::label('title', __('Title'),['class'=>'col-form-label col-form-label-sm'])); ?>

                        <?php echo e(Form::text('title', null, ['placeholder' => 'Enter Title','class'=>'form-control form-control-sm'])); ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <?php echo e(Form::label('date', __('Date'),['class'=>'col-form-label col-form-label-sm'])); ?>

                        <?php echo e(Form::text('date',$date ?? null, ['placeholder' => 'Select Date','class'=>'form-control form-control-sm datePicker'])); ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <div class="bootstrap-timepicker">
                            <?php echo e(Form::label('time', __('Time'),['class'=>'col-form-label col-form-label-sm'])); ?>

                            <?php echo e(Form::text('time', null, ['placeholder' => 'Enter Time','class'=>'form-control form-control-sm timepicker'])); ?>

                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <?php echo e(Form::label('is_all_day', __('Is all Day: '),['class'=>'col-form-label col-form-label-sm'])); ?>

                    <div class="form-check form-check-inline">
                        <?php echo e(Form::radio('is_all_day', '1' , 1,['class'=>'form-check-input'])); ?>

                        <?php echo e(Form::label('is_all_day', __('Yes'),['class'=>'form-check-label col-form-label-sm'])); ?>

                    </div>
                    <div class="form-check form-check-inline">
                        <?php echo e(Form::radio('is_all_day', '0' , 0,['class'=>'form-check-input'])); ?>

                        <?php echo e(Form::label('is_all_day', __('No'),['class'=>'form-check-label col-form-label-sm'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('description', __('Description'),['class'=>'col-form-label col-form-label-sm'])); ?>

                        <?php echo e(Form::textarea('description', null, ['placeholder' => 'Enter Description','class'=>'form-control form-control-sm'])); ?>

                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<div class="modal-footer justify-content-center">
    <button type="submit" class="btn btn-primary btn-sm"><?php echo e(__('Save changes')); ?></button>
    <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
</div>
<?php echo e(Form::close()); ?>

<?php /**PATH /opt/lampp/htdocs/envato/panjika/resources/views/admin/task/_create.blade.php ENDPATH**/ ?>