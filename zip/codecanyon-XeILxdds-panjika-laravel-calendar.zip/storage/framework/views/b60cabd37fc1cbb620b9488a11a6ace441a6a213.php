<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-free-5.6.3-web/css/all.min.css')); ?>">
    <!-- Nano Scroller -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/nanoScroller/nanoscroller.css')); ?>">

<?php echo $__env->yieldContent('plugin-css'); ?>

<!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/adminlte.min.css?ver:1.2')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/custom.css')); ?>">

    <!-- Bootstrap 4.6.0 -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/bootstrap-4.6.0-dist/css/bootstrap.min.css')); ?>">

    <!-- fullCalendar 5.7.0 -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/fullcalendar-5.7.0/lib/main.min.css')); ?>">


    <!-- Date Picker -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datepicker/datepicker3.css')); ?>">
    <!-- Time Picker -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/timepicker/bootstrap-timepicker.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('plugins/switch/switch.css')); ?>">

    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/favicon/')); ?>/<?php echo e(sysConfig('favicon')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom">
        <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <?php echo $__env->make('admin.includes.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- /.content-wrapper -->

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
        <?php echo $__env->make('admin.includes.right-aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </aside>
    <!-- /.control-sidebar -->

    <footer class="main-footer">
        <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>

    <!-- Bootstrap Alert -->
    <div class="modal fade" id="bootstrap-alert" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body bg-danger">
                    <?php if($errors->any()): ?>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-white">
                                    <?php echo e($error); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                    <div class="d-flex justify-content-center">
                        <button type="button" class="btn btn-outline-light" data-dismiss="modal">OK</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Bootstrap Alert -->

</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo e(asset('plugins/jquery/jquery-3.6.0.min.js')); ?>"></script>

<!-- Bootstrap 4.6.0 -->
<script src="<?php echo e(asset('plugins/bootstrap-4.6.0-dist/js/bootstrap.min.js')); ?>"></script>

<!-- jQuery UI 1.12.1 -->
<script src="<?php echo e(asset('plugins/jquery-ui-1.12.1/jquery-ui.min.js')); ?>"></script>
<!-- fullCalendar 5.7.0 -->
<script src="<?php echo e(asset('plugins/fullcalendar-5.7.0/lib/main.min.js')); ?>"></script>
<!-- Date Picker -->
<script src="<?php echo e(asset('plugins/datepicker/bootstrap-datepicker.js')); ?>"></script>
<!-- Time Picker -->
<script src="<?php echo e(asset('plugins/timepicker/bootstrap-timepicker.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('dist/js/adminlte.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('dist/js/demo.js')); ?>"></script>

<?php echo $__env->yieldContent('plugin'); ?>

<?php echo $__env->yieldContent('script'); ?>

<!-- Pop up validation error modal -->
<?php if($errors->any()): ?>
    <script>
        $("#bootstrap-alert").modal('show');
    </script>
<?php endif; ?>

<script type="text/javascript">
    $(document).ready(function() {
        //Datepicker
        $('.datePicker').datepicker({
            format : 'yyyy-mm-dd',
            autoclose : true
        })

        //Timepicker
        $('.timepicker').timepicker({
            showInputs: false,
            showMeridian: false,
            showSeconds: true
        })
    });

</script>

</body>
</html>
<?php /**PATH /opt/lampp/htdocs/envato/panjika/resources/views/layouts/admin.blade.php ENDPATH**/ ?>