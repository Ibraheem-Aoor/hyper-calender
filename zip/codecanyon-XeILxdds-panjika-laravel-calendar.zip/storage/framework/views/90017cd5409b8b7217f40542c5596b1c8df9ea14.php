<!-- Brand Logo -->
<a href="<?php echo e(url('dashboard')); ?>" class="brand-link">
    <img src="<?php echo e(asset('assets/img/logos')); ?>/<?php echo e(sysConfig('logo')); ?>" alt="Panjika Logo" class="brand-image img-circle elevation-3">
    <span class="brand-text font-weight-light"><?php echo e(sysConfig('title')); ?></span>
</a>
<!-- Sidebar -->
<div class="sidebar nano">
    <!-- Sidebar user panel (optional) -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
            <img src="<?php echo e(asset('assets/img/avatars')); ?>/<?php echo e(auth()->user()->avatar); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
            <a href="<?php echo e(url('/')); ?>" class="d-block"><?php echo e(auth()->user()->name); ?></a>
        </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <!-- Add icons to the links using the .nav-icon class
                 with font-awesome or any other icon font library -->
            <li class="nav-item has-treeview <?php echo e(isActive(['/','dashboard*'])); ?>">
                <a href="<?php echo e(url('dashboard')); ?>" class="nav-link <?php echo e(isActive(['dashboard*','/'])); ?>">
                    <i class="nav-icon fas fa-tachometer-alt"></i>
                    <p>
                        <?php echo e(__('Dashboard')); ?>

                    </p>
                </a>
            </li>

            <li class="nav-item has-treeview <?php echo e(isActive(['event*'])); ?>">
                <a href="<?php echo e(url('events')); ?>" class="nav-link <?php echo e(isActive('event')); ?>">
                    <i class="fas fa-glass-cheers"></i>
                    <p><?php echo e(__('Event')); ?></p>
                </a>
            </li>

            <li class="nav-item has-treeview <?php echo e(isActive(['task*'])); ?>">
                <a href="<?php echo e(url('tasks')); ?>" class="nav-link <?php echo e(isActive('task')); ?>">
                    <i class="far fa-check-circle"></i>
                    <p><?php echo e(__('Task')); ?></p>
                </a>
            </li>

            <li class="nav-item has-treeview <?php echo e(isActive(['reminder*'])); ?>">
                <a href="<?php echo e(url('reminders')); ?>" class="nav-link <?php echo e(isActive('reminder')); ?>">
                    <i class="fas fa-stopwatch"></i>
                    <p><?php echo e(__('Reminder')); ?></p>
                </a>
            </li>

            <li class="nav-item has-treeview <?php echo e(isActive(['setting*'])); ?>">
                <a href="#" class="nav-link <?php echo e(isActive(['setting*'])); ?>">
                    <i class="fas fa-shapes"></i>
                    <p>
                        <?php echo e(__('Settings')); ?>

                        <i class="fas fa-angle-left right"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?php echo e(url('setting/systemSetting')); ?>" class="nav-link <?php echo e(isActive('setting/systemSetting')); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p><?php echo e(__('System Settings')); ?></p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('setting/basicInfo')); ?>" class="nav-link <?php echo e(isActive('setting/basicInfo')); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p><?php echo e(__('Company Settings')); ?></p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('setting/email')); ?>" class="nav-link <?php echo e(isActive('setting/email')); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p><?php echo e(__('E-mail Settings')); ?></p>
                        </a>
                    </li>

                </ul>
            </li>

        </ul>
    </nav>
    <!-- /.sidebar-menu -->

</div>
<?php /**PATH /opt/lampp/htdocs/envato/panjika/resources/views/admin/includes/left-sidebar.blade.php ENDPATH**/ ?>