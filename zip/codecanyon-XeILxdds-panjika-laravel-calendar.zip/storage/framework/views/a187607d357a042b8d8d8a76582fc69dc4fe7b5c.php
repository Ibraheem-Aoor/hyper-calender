<?php $__env->startSection('title',sysConfig('title')); ?>

<?php $__env->startSection('content'); ?>

    <main class="px-3">
        <h1><?php echo e(__('Use your time wisely')); ?></h1>
        <p class="lead"><?php echo e(__("It doesn't matter what your business does—time is your most valuable resource. You need to make sure you're spending that time wisely, and the calendar is your budget. That's why it's so important you find the best calendar app for the job.")); ?></p>
        <p class="lead">
            <a href="https://codecanyon.net/item/panjika-laravel-calendar/32283666/" class="btn btn-lg btn-secondary fw-bold border-white bg-white"><?php echo e(__('Buy Now')); ?></a>
        </p>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/envato/panjika/resources/views/cover.blade.php ENDPATH**/ ?>