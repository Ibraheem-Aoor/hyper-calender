<?php $__env->startSection('title','Add Event'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark"><?php echo e(__('Events')); ?></h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#"><?php echo e(__('Home')); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e(__('Add New Event')); ?></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(Session::get('success')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="pl-3">
                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo"> <i class="fas fa-plus-circle"></i> Add An Event</button>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered table-hover text-secondary">
                                    <thead class="thead-dark">
                                    <tr>
                                        <th class="text-center">#<?php echo e(__('ID')); ?></th>
                                        <th class="text-center"><?php echo e(__('Title')); ?></th>
                                        <th class="text-center"><?php echo e(__('Time')); ?></th>
                                        <th class="text-center"><?php echo e(__('Details')); ?></th>
                                        <th class="text-center"><?php echo e(__('Action')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"> <?php echo e($event->id); ?></td>
                                            <td class=""> <?php echo e($event->title); ?> </td>
                                            <td class="">
                                                <b>Start:</b> <?php echo e(panDate($event->start_date)); ?> <?php echo e($event->start_time ? panTime($event->start_time) : ''); ?><br>
                                                <b>End:</b> <?php echo e($event->end_date ? panDate($event->end_date) : ''); ?> <?php echo e($event->end_time ? panTime($event->end_time) : ''); ?>

                                                <br>
                                                <span  class="text-black-50 text-center"><small><em>Repeat: <?php echo e($event->repeat->name ?? 'Do not repeat'); ?></em></small></span>
                                            </td>
                                            <td class="">
                                                Guest: <?php echo e($event->guests); ?><br>
                                                Location: <?php echo e($event->locations); ?><br>
                                                <?php echo e($event->description); ?>

                                            </td>
                                            <td class="text-center">
                                                <?php echo e(Form::open(['route'=>['event.delete',$event->id],'method'=>'post','onsubmit'=>'return confirmDelete()'])); ?>

                                                <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#exampleEditModal" onclick="loadEditForm(<?php echo e($event->id); ?>)"><i class="fas fa-edit"></i></button>
                                                <button type="submit" class="btn btn-danger btn-sm">
                                                    <i class="fa fas fa-trash"></i>
                                                </button>
                                                <?php echo e(Form::close()); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.card -->

            </div>
            <!--/.col (left) -->
            <div class="col-md-12">
                <div class="card-body">
                    <div class="text-center">
                        <?php echo e($events->links()); ?>

                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->

    <!-- modal for add event starts here-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Add New Event')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php echo $__env->make('admin.event._create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
    <!-- modal for add event ends here -->


    <!-- Edit Modal -->
    <div class="modal fade" id="exampleEditModal" tabindex="-1" aria-labelledby="exampleEditModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" id="modal-content">
                <!-- Edit form will appeared here -->
                <img src="<?php echo e(asset('dist/img/fcs.gif')); ?>" alt="" id="loader">
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function confirmDelete(){
            var x = confirm('Are you sure you want to delete this event?');
            return !!x;
        }
    </script>
    <script>
        function loadEditForm(id){
            var token = "<?php echo e(csrf_token()); ?>";
            $.ajax({
                url:"<?php echo e(route('event.edit')); ?>",
                data: {_token:token,id:id},
                type: 'get',
                beforeSend: function(){
                    $("#loader").show();
                }
            }).done(function(e){
                $("#edit-form").remove();
                $("#loader").hide();
                $("#modal-content").html(e);
                /** load date picker in edit form */
                $('.datePicker').datepicker({
                    format : 'yyyy-mm-dd',
                    autoclose : true
                })
                /** load time picker in edit form */
                $('.timepicker').timepicker({
                    showInputs: false,
                    showMeridian: false,
                    showSeconds: true
                })
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/envato/panjika/resources/views/admin/event/index.blade.php ENDPATH**/ ?>