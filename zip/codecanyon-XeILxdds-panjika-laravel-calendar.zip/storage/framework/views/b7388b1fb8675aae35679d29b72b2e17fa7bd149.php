<?php $__env->startSection('title','Dashboard One'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e(__('Calendar')); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#"><?php echo e(__('Home')); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e(__('Calendar')); ?></li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- /.col -->
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-body p-0">
                            <!-- THE CALENDAR -->
                            <div id="calendar">
                                <!-- The calendar will appeared here -->
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /. box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" id="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Add to Calendar')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img src="<?php echo e(asset('dist/img/fcs.gif')); ?>" alt="" id="loader">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                    <button type="button" class="btn btn-primary"><?php echo e(__('Save changes')); ?></button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>

        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');

            var calendar = new FullCalendar.Calendar(calendarEl, {
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
                },
                initialDate: '<?php echo e(today()); ?>',
                navLinks: false, // can click day/week names to navigate views
                businessHours: false, // display business hours
                editable: true,
                selectable: true,
                events: [
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                        id          : '<?php echo e($event->id); ?>',
                        title       : '<?php echo e($event->title); ?>',
                        start       : '<?php echo e($event->start_date ? $event->start_date->format('Y-m-d') : ''); ?>T<?php echo e($event->start_time ? $event->start_time->format('H:i:s') : ''); ?>',
                        end         : '<?php echo e($event->end_date ? $event->end_date->format('Y-m-d') : ''); ?>T<?php echo e($event->start_time ? $event->start_time->format('H:i:s') : ''); ?>',
                        color       : '#f56954',
                        borderColor : '#f56954',
                        type        : 'event',
                    },
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $reminders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reminder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                        id          : '<?php echo e($reminder->id); ?>',
                        title       : '<?php echo e($reminder->title); ?>',
                        start       : '<?php echo e($reminder->date->format('Y-m-d')); ?><?php echo e($reminder->is_all_day ?'':'T'.$reminder->date->format('H:i:s')); ?>',
                        color       : '#f39c12',
                        borderColor : '#f39c12',
                        allDay      : <?php echo e($reminder->is_all_day ? 'true' : 'false'); ?>,
                        type        : 'reminder'
                    },
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                        id          : '<?php echo e($task->id); ?>',
                        title       : '<?php echo e($task->title); ?>',
                        start       : '<?php echo e($task->date->format('Y-m-d')); ?><?php echo e($task->is_all_day ?'':'T'.$task->date->format('H:i:s')); ?>',
                        color       : '#0073b7',
                        borderColor : '#0073b7',
                        allDay      : <?php echo e($task->is_all_day ? 'true' : 'false'); ?>,
                        type        : 'task'
                    },
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],

                // Popup edit form for task/reminder/event
                eventClick: function(info){
                    $('#exampleModal').modal('show')
                    var csrf = "<?php echo e(csrf_token()); ?>";
                    $.ajax({
                        url : "<?php echo e(route('calendar-event')); ?>",
                        data: {_token:csrf,id:info.event.id,type:info.event.extendedProps.type},
                        type: "POST",
                        beforeSend: function(){
                            $("#loader").show();
                        }
                    }).done(function(e){
                        $("#modal-content").html(e);
                        /** load date picker in edit form */
                        $('.datePicker').datepicker({
                            format : 'yyyy-mm-dd',
                            autoclose : true
                        })
                        /** load time picker in edit form */
                        $('.timepicker').timepicker({
                            showInputs: false,
                            showMeridian: false,
                            showSeconds: true
                        })
                    })
                },
            });

            calendar.render();

            /** Activate add new modal after clicking previous button */
            $('.fc-prev-button').click(function(){
                addNewModal();
            });
            /** Activate add new modal after clicking next button */
            $('.fc-next-button').click(function(){
                addNewModal()
            });
            /** Activate add new modal after clicking today button */
            $('.fc-today-button').click(function(){
                addNewModal()
            });
            /** Activate add new modal after clicking month button */
            $('.fc-month-button').click(function(){
                addNewModal()
            });

            addNewModal()
        });

    </script>

    <script>
        $(".nano").nanoScroller({
            preventPageScrolling: true,
        });
    </script>

    <script>
        function addNewModal(){
            // Popup modal for creating new task/reminder/event
            $(".fc-daygrid-day-number").click(function(){
                var date = $(this).data('date')
                var csrf = "<?php echo e(csrf_token()); ?>";
                $('#exampleModal').modal('show')
                $.ajax({
                    url : "<?php echo e(route('calendar-add')); ?>",
                    data: {_token:csrf,date:date},
                    type: "POST",
                    beforeSend: function(){
                        $("#loader").show();
                    }
                }).done(function(e){
                    $("#modal-content").html(e);
                    /** load date picker in edit form */
                    $('.datePicker').datepicker({
                        format : 'yyyy-mm-dd',
                        autoclose : true
                    })
                    /** load time picker in edit form */
                    $('.timepicker').timepicker({
                        showInputs: false,
                        showMeridian: false,
                        showSeconds: true
                    })
                })
            })

            $(".fc-daygrid-day-number").css('cursor','pointer');
            $(".fc-event-container").css('cursor','pointer');
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/envato/panjika/resources/views/index.blade.php ENDPATH**/ ?>